Iconset: Essentials Pack (https://www.iconfinder.com/iconsets/essentials-pack)
Author: Deemak Daksina (https://www.iconfinder.com/deemakdaksina)
License: Free for commercial use (Include link to authors website) ()
Download date: 2023-11-09